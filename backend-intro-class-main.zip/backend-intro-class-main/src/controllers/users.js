const getUser = (req, res) => {
    res.send("get all users...............");
}

module.exports = getUser